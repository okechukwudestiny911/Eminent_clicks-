import {
  addDoc,
  collection,
  doc,
  getFirestore,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
  updateDoc,
  type DocumentData,
  type Timestamp,
} from 'firebase/firestore';
import {
  getDownloadURL,
  getStorage,
  ref,
  uploadBytesResumable,
} from 'firebase/storage';
import { getApp, getApps, initializeApp } from 'firebase/app';
import type { PaymentRecord, PaymentStatus, ToolId } from './domain';

const requiredKeys = [
  'VITE_FIREBASE_API_KEY',
  'VITE_FIREBASE_AUTH_DOMAIN',
  'VITE_FIREBASE_PROJECT_ID',
  'VITE_FIREBASE_STORAGE_BUCKET',
  'VITE_FIREBASE_MESSAGING_SENDER_ID',
  'VITE_FIREBASE_APP_ID',
] as const;

const config = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID,
};

export const isFirebaseConfigured = requiredKeys.every(
  (key) => Boolean(import.meta.env[key]),
);

const firebaseApp = isFirebaseConfigured
  ? getApps().length
    ? getApp()
    : initializeApp(config)
  : null;

const firestore = firebaseApp ? getFirestore(firebaseApp) : null;
const storage = firebaseApp ? getStorage(firebaseApp) : null;

const toPaymentRecord = (id: string, data: DocumentData): PaymentRecord => {
  const submittedAt = data.submittedAt as Timestamp | undefined;

  return {
    id,
    trackingCode: String(data.trackingCode ?? ''),
    email: String(data.email ?? ''),
    whatsapp: String(data.whatsapp ?? ''),
    toolId: data.toolId as ToolId,
    toolName: String(data.toolName ?? ''),
    amount: Number(data.amount ?? 0),
    receiptUrl: String(data.receiptUrl ?? ''),
    receiptPath: String(data.receiptPath ?? ''),
    submittedAt: submittedAt?.toDate() ?? new Date(),
    status: (data.status ?? 'Pending') as PaymentStatus,
  };
};

export const subscribeToPayments = (
  onChange: (payments: PaymentRecord[]) => void,
  onError: (error: Error) => void,
) => {
  if (!firestore) {
    onChange([]);
    return () => undefined;
  }

  const paymentsQuery = query(
    collection(firestore, 'eminent_payments'),
    orderBy('submittedAt', 'desc'),
  );

  return onSnapshot(
    paymentsQuery,
    (snapshot) =>
      onChange(
        snapshot.docs.map((payment) =>
          toPaymentRecord(payment.id, payment.data()),
        ),
      ),
    (error) => onError(error),
  );
};

const compressReceipt = (file: File) =>
  new Promise<Blob>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const image = new Image();
      image.onload = () => {
        const maxDimension = 1600;
        const scale = Math.min(1, maxDimension / Math.max(image.width, image.height));
        const canvas = document.createElement('canvas');
        canvas.width = Math.max(1, Math.round(image.width * scale));
        canvas.height = Math.max(1, Math.round(image.height * scale));
        const context = canvas.getContext('2d');
        if (!context) {
          reject(new Error('Receipt image could not be processed.'));
          return;
        }
        context.drawImage(image, 0, 0, canvas.width, canvas.height);
        canvas.toBlob(
          (blob) => (blob ? resolve(blob) : reject(new Error('Receipt compression failed.'))),
          'image/jpeg',
          0.72,
        );
      };
      image.onerror = () => reject(new Error('Receipt image could not be read.'));
      image.src = String(reader.result);
    };
    reader.onerror = () => reject(new Error('Receipt file could not be read.'));
    reader.readAsDataURL(file);
  });

const randomDigits = () => {
  const array = new Uint32Array(1);
  crypto.getRandomValues(array);
  return String(array[0] % 10000).padStart(4, '0');
};

export const createTrackingCode = () =>
  `EC-NGN-${randomDigits()}-${randomDigits()}`;

export type PaymentSubmission = {
  email: string;
  whatsapp: string;
  toolId: ToolId;
  toolName: string;
  amount: number;
  receipt: File;
};

export const submitPayment = async (
  submission: PaymentSubmission,
  onProgress: (progress: number) => void,
) => {
  if (!firestore || !storage) {
    throw new Error(
      'Firebase is not configured yet. Add the VITE_FIREBASE_* values to enable uploads.',
    );
  }

  const trackingCode = createTrackingCode();
  const compressed = await compressReceipt(submission.receipt);
  const extension = submission.receipt.type === 'image/png' ? 'png' : 'jpg';
  const receiptPath = `receipts/${trackingCode}.${extension}`;
  const upload = uploadBytesResumable(
    ref(storage, receiptPath),
    compressed,
    {
      contentType: extension === 'png' ? 'image/png' : 'image/jpeg',
      customMetadata: {
        originalName: submission.receipt.name,
        trackingCode,
      },
    },
  );

  await new Promise<void>((resolve, reject) => {
    const startedAt = Date.now();
    const timer = window.setInterval(() => {
      const elapsedProgress = Math.min(88, Math.round(((Date.now() - startedAt) / 1200) * 88));
      onProgress(elapsedProgress);
    }, 80);

    upload.on(
      'state_changed',
      (snapshot) => {
        const firebaseProgress =
          snapshot.totalBytes > 0
            ? Math.round((snapshot.bytesTransferred / snapshot.totalBytes) * 100)
            : 0;
        onProgress(Math.max(firebaseProgress, 12));
      },
      (error) => {
        window.clearInterval(timer);
        reject(error);
      },
      () => {
        window.clearInterval(timer);
        onProgress(96);
        resolve();
      },
    );
  });

  const receiptUrl = await getDownloadURL(ref(storage, receiptPath));
  const payment = await addDoc(collection(firestore, 'eminent_payments'), {
    trackingCode,
    email: submission.email,
    whatsapp: submission.whatsapp,
    toolId: submission.toolId,
    toolName: submission.toolName,
    amount: submission.amount,
    receiptUrl,
    receiptPath,
    status: 'Pending',
    submittedAt: serverTimestamp(),
  });

  onProgress(100);

  return { id: payment.id, trackingCode };
};

export const updatePaymentStatus = async (
  paymentId: string,
  status: PaymentStatus,
) => {
  if (!firestore) {
    throw new Error('Firebase is not configured yet.');
  }

  await updateDoc(doc(firestore, 'eminent_payments', paymentId), { status });
};
