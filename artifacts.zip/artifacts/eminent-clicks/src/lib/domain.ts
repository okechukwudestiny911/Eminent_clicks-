export type PaymentStatus = 'Pending' | 'Approved' | 'Rejected';

export type ToolId =
  | 'subtrack'
  | 'jobflow'
  | 'paychaser'
  | 'reportsnap'
  | 'claimdesk';

export type ToolDefinition = {
  id: ToolId;
  name: string;
  shortName: string;
  description: string;
  price: number;
  eyebrow: string;
  accent: string;
  icon: string;
};

export type PaymentRecord = {
  id: string;
  trackingCode: string;
  email: string;
  whatsapp: string;
  toolId: ToolId;
  toolName: string;
  amount: number;
  receiptUrl: string;
  receiptPath: string;
  submittedAt: Date;
  status: PaymentStatus;
};

export const TOOLS: ToolDefinition[] = [
  {
    id: 'subtrack',
    name: 'SubTrack',
    shortName: 'Subscriptions',
    description: 'Keep recurring costs visible before they renew.',
    price: 5000,
    eyebrow: 'Recurring costs',
    accent: '#d9f99d',
    icon: 'repeat',
  },
  {
    id: 'jobflow',
    name: 'JobFlow',
    shortName: 'Jobs',
    description: 'Move every trade job from quote to paid.',
    price: 10000,
    eyebrow: 'Trade workflow',
    accent: '#bfdbfe',
    icon: 'briefcase-business',
  },
  {
    id: 'paychaser',
    name: 'PayChaser',
    shortName: 'Invoices',
    description: 'Follow up on money owed without the awkwardness.',
    price: 10000,
    eyebrow: 'Invoice follow-up',
    accent: '#fed7aa',
    icon: 'receipt-text',
  },
  {
    id: 'reportsnap',
    name: 'ReportSnap',
    shortName: 'Reports',
    description: 'See sales, expenses, and profit in one view.',
    price: 10000,
    eyebrow: 'Business intelligence',
    accent: '#ddd6fe',
    icon: 'chart-no-axes-combined',
  },
  {
    id: 'claimdesk',
    name: 'ClaimDesk',
    shortName: 'Claims',
    description: 'Log receipts and keep business claims organized.',
    price: 10000,
    eyebrow: 'Expense claims',
    accent: '#a7f3d0',
    icon: 'file-check-2',
  },
];

export const formatNaira = (amount: number) =>
  new Intl.NumberFormat('en-NG', {
    style: 'currency',
    currency: 'NGN',
    maximumFractionDigits: 0,
  }).format(amount);

export const formatDate = (date: Date) =>
  new Intl.DateTimeFormat('en-NG', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  }).format(date);

export const getTool = (toolId: ToolId) =>
  TOOLS.find((tool) => tool.id === toolId) ?? TOOLS[0];
