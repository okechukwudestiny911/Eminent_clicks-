import { useEffect, useMemo, useRef, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import {
  ArrowLeft,
  ArrowRight,
  BarChart3,
  Bell,
  BriefcaseBusiness,
  CalendarClock,
  Check,
  CheckCircle2,
  ChevronDown,
  CircleAlert,
  ClipboardCheck,
  Clock3,
  Copy,
  CreditCard,
  FileCheck2,
  FileImage,
  FileText,
  HandCoins,
  Landmark,
  LayoutDashboard,
  LifeBuoy,
  LockKeyhole,
  Menu,
  MoreHorizontal,
  Paperclip,
  Plus,
  Receipt,
  RefreshCw,
  Search,
  Send,
  ShieldCheck,
  Sparkles,
  UploadCloud,
  WalletCards,
  X,
} from 'lucide-react';
import { Link, Route, Switch, Router as WouterRouter, useLocation, useParams } from 'wouter';
import type { LucideIcon } from 'lucide-react';
import {
  isFirebaseConfigured,
  submitPayment,
  subscribeToPayments,
  updatePaymentStatus,
} from '@/lib/firebase';
import type { PaymentStatus as FirebasePaymentStatus } from '@/lib/domain';

const queryClient = new QueryClient();

type ToolId = 'subtrack' | 'jobflow' | 'paychaser' | 'reportsnap' | 'claimdesk';
type PaymentStatus = 'Pending' | 'Approved' | 'Rejected';

type Tool = {
  id: ToolId;
  name: string;
  description: string;
  price: number;
  icon: LucideIcon;
  accent: string;
  eyebrow: string;
};

type Payment = {
  id: string;
  trackingCode: string;
  email: string;
  whatsapp: string;
  toolId: ToolId;
  toolName: string;
  amount: number;
  receiptUrl: string;
  receiptPath: string;
  submittedAt: string;
  status: FirebasePaymentStatus;
};

type Subscription = { service: string; category: string; monthlyCost: number; renewalDate: string };
type Job = { client: string; service: string; amount: number; status: string; notes: string; updatedAt: string };
type Invoice = { client: string; invoiceNumber: string; amount: number; dueDate: string; status: string };
type Claim = { vendor: string; category: string; amount: number; receiptUrl: string; submittedAt: string };
type Report = { period: string; sales: number; expenses: number; profit: number };

const TOOLS: Tool[] = [
  { id: 'subtrack', name: 'SubTrack', description: 'Keep recurring costs and renewal dates in view.', price: 5000, icon: RefreshCw, accent: '#2f7d72', eyebrow: 'Recurring costs' },
  { id: 'jobflow', name: 'JobFlow', description: 'Move client work from accepted to paid without loose ends.', price: 10000, icon: BriefcaseBusiness, accent: '#c3742f', eyebrow: 'Work pipeline' },
  { id: 'paychaser', name: 'PayChaser', description: 'Make invoice follow-up feel measured, not awkward.', price: 10000, icon: Send, accent: '#5f7d9b', eyebrow: 'Invoice follow-up' },
  { id: 'reportsnap', name: 'ReportSnap', description: 'See the month clearly before making the next move.', price: 10000, icon: BarChart3, accent: '#8d6b9d', eyebrow: 'Finance snapshot' },
  { id: 'claimdesk', name: 'ClaimDesk', description: 'Bring vendor claims and supporting receipts together.', price: 10000, icon: HandCoins, accent: '#ba5c51', eyebrow: 'Claims & receipts' },
];

const money = (value: number) => `₦${value.toLocaleString('en-NG')}`;
const today = () => new Date().toLocaleDateString('en-NG', { day: 'numeric', month: 'short', year: 'numeric' });

function BrandMark({ onLongPress }: { onLongPress?: () => void }) {
  const timerRef = useRef<number | null>(null);
  const startLongPress = () => {
    if (!onLongPress) return;
    timerRef.current = window.setTimeout(onLongPress, 1500);
  };
  const cancelLongPress = () => {
    if (timerRef.current) window.clearTimeout(timerRef.current);
    timerRef.current = null;
  };

  return (
    <button
      type="button"
      onPointerDown={startLongPress}
      onPointerUp={cancelLongPress}
      onPointerLeave={cancelLongPress}
      onContextMenu={(event) => event.preventDefault()}
      className="focus-ring flex items-center gap-3 text-left"
      data-testid="button-brand-mark"
      aria-label="Eminent Clicks"
    >
      <span className="grid size-9 place-items-center rounded-full bg-[hsl(var(--primary))] text-[hsl(var(--primary-foreground))] shadow-[0_6px_16px_hsl(var(--primary)/.2)]">
        <span className="font-display text-xl font-semibold leading-none">E</span>
      </span>
      <span className="leading-tight">
        <span className="block text-[13px] font-extrabold tracking-[-.02em]">Eminent Clicks</span>
        <span className="block font-mono-ui text-[9px] uppercase tracking-[.18em] text-[hsl(var(--sidebar-foreground)/.55)]">Business desk</span>
      </span>
    </button>
  );
}

function Shell({ children, isAdmin, onAdminTrigger }: { children: React.ReactNode; isAdmin?: boolean; onAdminTrigger: () => void }) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const dashboardTaps = useRef<number[]>([]);
  const navTools = TOOLS;
  const handleDashboardTap = () => {
    const now = Date.now();
    dashboardTaps.current = [...dashboardTaps.current.filter((tap) => now - tap < 2000), now];
    if (dashboardTaps.current.length >= 3) {
      dashboardTaps.current = [];
      onAdminTrigger();
    }
  };
  return (
    <div className="noise-layer min-h-[100dvh] bg-[hsl(var(--background))]">
      <aside className={`fixed inset-y-0 left-0 z-40 flex w-[250px] flex-col bg-[hsl(var(--sidebar))] px-5 py-6 text-[hsl(var(--sidebar-foreground))] transition-transform duration-300 lg:translate-x-0 ${mobileOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="flex items-center justify-between">
           <BrandMark onLongPress={onAdminTrigger} />
          <button type="button" onClick={() => setMobileOpen(false)} className="focus-ring rounded-lg p-2 text-white/55 hover:bg-white/10 lg:hidden" data-testid="button-close-mobile-nav"><X size={17} /></button>
        </div>
        <div className="mt-10">
          <p className="px-3 font-mono-ui text-[9px] uppercase tracking-[.2em] text-white/35">Workspace</p>
          <nav className="mt-3 space-y-1">
             <Link href="/" onClick={() => { setMobileOpen(false); handleDashboardTap(); }} className={`focus-ring flex items-center gap-3 rounded-xl px-3 py-2.5 text-[13px] font-semibold transition-colors ${!isAdmin ? 'bg-white/10 text-white' : 'text-white/60 hover:bg-white/6 hover:text-white'}`} data-testid="link-overview">
               <LayoutDashboard size={16} /><span>My Dashboard</span>
            </Link>
            {isAdmin && <Link href="/admin" onClick={() => setMobileOpen(false)} className="focus-ring flex items-center gap-3 rounded-xl bg-[hsl(var(--primary)/.16)] px-3 py-2.5 text-[13px] font-semibold text-[hsl(var(--primary))]" data-testid="link-admin-payments"><CreditCard size={16} /><span>Payment desk</span><span className="ml-auto rounded-full bg-[hsl(var(--primary))] px-1.5 py-0.5 font-mono-ui text-[9px] text-[hsl(var(--primary-foreground))]">ADMIN</span></Link>}
          </nav>
        </div>
        <div className="mt-8">
          <p className="px-3 font-mono-ui text-[9px] uppercase tracking-[.2em] text-white/35">Tools</p>
          <nav className="mt-3 space-y-1">
            {navTools.map((tool) => {
              const Icon = tool.icon;
              return <Link key={tool.id} href={`/tool/${tool.id}`} onClick={() => setMobileOpen(false)} className="focus-ring group flex items-center gap-3 rounded-xl px-3 py-2.5 text-[13px] font-medium text-white/58 transition-colors hover:bg-white/7 hover:text-white" data-testid={`link-tool-${tool.id}`}><span className="grid size-6 place-items-center rounded-lg bg-white/7 transition-colors group-hover:bg-white/12" style={{ color: tool.accent }}><Icon size={14} /></span><span>{tool.name}</span><ArrowRight size={13} className="ml-auto opacity-0 transition-opacity group-hover:opacity-60" /></Link>;
            })}
          </nav>
        </div>
        <div className="mt-auto rounded-2xl border border-white/10 bg-white/6 p-4">
          <div className="flex items-start gap-2.5"><ShieldCheck size={17} className="mt-0.5 text-[hsl(var(--primary))]" /><div><p className="text-[12px] font-bold">Your desk, kept private</p><p className="mt-1 text-[11px] leading-relaxed text-white/48">Payment receipts are reviewed before any tool is unlocked.</p></div></div>
        </div>
        <p className="mt-5 px-1 font-mono-ui text-[9px] tracking-[.08em] text-white/25">v1.0 · LAGOS / NIGERIA</p>
      </aside>
      {mobileOpen && <button type="button" aria-label="Close navigation" onClick={() => setMobileOpen(false)} className="fixed inset-0 z-30 bg-[hsl(var(--sidebar)/.5)] lg:hidden" data-testid="button-nav-backdrop" />}
      <main className="min-h-[100dvh] lg:pl-[250px]">
        <header className="sticky top-0 z-20 flex h-[72px] items-center justify-between border-b border-[hsl(var(--border)/.7)] bg-[hsl(var(--background)/.9)] px-5 backdrop-blur-md sm:px-8 lg:px-11">
          <button type="button" onClick={() => setMobileOpen(true)} className="focus-ring rounded-xl p-2 text-[hsl(var(--muted-foreground))] hover:bg-[hsl(var(--muted))] lg:hidden" data-testid="button-open-mobile-nav"><Menu size={20} /></button>
          <div className="hidden items-center gap-2 text-[12px] text-[hsl(var(--muted-foreground))] lg:flex"><span className="size-1.5 rounded-full bg-[hsl(var(--accent))]" /><span>Operations are quiet today.</span></div>
          <div className="ml-auto flex items-center gap-3">
            <button type="button" className="focus-ring relative rounded-xl p-2 text-[hsl(var(--muted-foreground))] transition-colors hover:bg-[hsl(var(--muted))] hover:text-[hsl(var(--foreground))]" data-testid="button-notifications"><Bell size={17} /><span className="absolute right-1.5 top-1.5 size-1.5 rounded-full bg-[hsl(var(--primary))]" /></button>
            <div className="hidden h-6 w-px bg-[hsl(var(--border))] sm:block" />
            <button type="button" className="focus-ring flex items-center gap-2 rounded-xl py-1 pl-1 pr-2 transition-colors hover:bg-[hsl(var(--muted))]" data-testid="button-profile-menu"><span className="grid size-8 place-items-center rounded-lg bg-[hsl(var(--secondary))] font-display text-sm font-semibold text-[hsl(var(--secondary-foreground))]">EC</span><span className="hidden text-left sm:block"><span className="block text-[11px] font-bold">Owner desk</span><span className="block text-[10px] text-[hsl(var(--muted-foreground))]">Workspace admin</span></span><ChevronDown size={14} className="text-[hsl(var(--muted-foreground))]" /></button>
          </div>
        </header>
        {children}
      </main>
    </div>
  );
}

function SectionLabel({ children }: { children: React.ReactNode }) {
  return <p className="font-mono-ui text-[10px] uppercase tracking-[.18em] text-[hsl(var(--muted-foreground))]">{children}</p>;
}

function Dashboard({ onPay, payments, unlocked }: { onPay: (tool: Tool) => void; payments: Payment[]; unlocked: Set<ToolId> }) {
  const [search, setSearch] = useState('');
  const [logoClicks, setLogoClicks] = useState(0);
  const filteredTools = useMemo(() => TOOLS.filter((tool) => `${tool.name} ${tool.description}`.toLowerCase().includes(search.toLowerCase())), [search]);
  return (
    <div className="mx-auto max-w-[1440px] px-5 py-8 sm:px-8 lg:px-11 lg:py-10">
      <div className="animate-rise flex flex-col justify-between gap-6 sm:flex-row sm:items-end">
        <div><SectionLabel>Tuesday, {today()}</SectionLabel><h1 className="mt-3 max-w-2xl font-display text-[clamp(2.6rem,5vw,4.4rem)] leading-[.94] tracking-[-.055em] text-[hsl(var(--foreground))]">A clearer day<br /><em className="text-[hsl(var(--accent))]">starts here.</em></h1><p className="mt-5 max-w-lg text-[14px] leading-relaxed text-[hsl(var(--muted-foreground))]">Your essential business controls, set down in one calm place.</p></div>
        <div className="flex items-center gap-2"><div className="relative"><Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-[hsl(var(--muted-foreground))]" /><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Find a tool" className="focus-ring h-10 w-full rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] pl-9 pr-3 text-[12px] outline-none placeholder:text-[hsl(var(--muted-foreground))] sm:w-44" data-testid="input-tool-search" /></div><button type="button" onClick={() => onPay(TOOLS[0])} className="focus-ring inline-flex h-10 items-center gap-2 rounded-xl bg-[hsl(var(--primary))] px-4 text-[12px] font-extrabold text-[hsl(var(--primary-foreground))] shadow-[0_5px_16px_hsl(var(--primary)/.18)] transition-transform hover:-translate-y-0.5" data-testid="button-quick-payment"><Plus size={15} /> Add access</button></div>
      </div>

      <div className="mt-9 grid gap-4 md:grid-cols-[1.3fr_.7fr_.7fr]">
        <div className="animate-rise relative overflow-hidden rounded-2xl bg-[hsl(var(--sidebar))] p-6 text-white shadow-[var(--shadow-md)] [animation-delay:80ms] sm:p-7">
          <div className="absolute -right-10 -top-14 size-48 rounded-full border-[24px] border-[hsl(var(--primary)/.12)]" /><div className="absolute -right-2 top-5 size-28 rounded-full border border-[hsl(var(--primary)/.18)]" />
          <div className="relative"><div className="flex items-center gap-2"><span className="grid size-7 place-items-center rounded-lg bg-[hsl(var(--primary))] text-[hsl(var(--primary-foreground))]"><Sparkles size={14} /></span><span className="font-mono-ui text-[10px] uppercase tracking-[.15em] text-white/55">Operating desk</span></div><h2 className="mt-8 max-w-md font-display text-3xl leading-[1.05] tracking-[-.03em] sm:text-[2.2rem]">One login.<br /><span className="text-[hsl(var(--primary))]">Pay once, unlock instantly.</span></h2><p className="mt-4 max-w-sm text-[12px] leading-relaxed text-white/58">Start with what your business needs today. Add the rest when the timing is right.</p><button type="button" onClick={() => onPay(TOOLS[0])} className="focus-ring mt-7 inline-flex items-center gap-2 rounded-xl bg-white px-4 py-2.5 text-[12px] font-extrabold text-[hsl(var(--sidebar))] transition-transform hover:-translate-y-0.5" data-testid="button-hero-add-access">Explore your toolkit <ArrowRight size={15} /></button></div>
        </div>
        <div className="animate-rise rounded-2xl border border-[hsl(var(--card-border))] bg-[hsl(var(--card))] p-6 [animation-delay:150ms]"><div className="flex items-center justify-between"><span className="grid size-9 place-items-center rounded-xl bg-[hsl(var(--secondary))] text-[hsl(var(--secondary-foreground))]"><WalletCards size={17} /></span><span className="font-mono-ui text-[10px] text-[hsl(var(--muted-foreground))]">THIS MONTH</span></div><p className="mt-9 text-[12px] text-[hsl(var(--muted-foreground))]">Recurring outgoings</p><p className="mt-1 font-display text-3xl tracking-[-.04em]">—</p><p className="mt-2 text-[11px] text-[hsl(var(--muted-foreground))]">Add SubTrack to see the full picture.</p></div>
        <div className="animate-rise rounded-2xl border border-[hsl(var(--card-border))] bg-[hsl(var(--card))] p-6 [animation-delay:220ms]"><div className="flex items-center justify-between"><span className="grid size-9 place-items-center rounded-xl bg-[hsl(var(--primary)/.15)] text-[hsl(var(--primary))]"><ClipboardCheck size={17} /></span><span className="font-mono-ui text-[10px] text-[hsl(var(--muted-foreground))]">IN VIEW</span></div><p className="mt-9 text-[12px] text-[hsl(var(--muted-foreground))]">Open items</p><p className="mt-1 font-display text-3xl tracking-[-.04em]">{payments.length}</p><p className="mt-2 text-[11px] text-[hsl(var(--muted-foreground))]">{payments.length ? 'Payments awaiting review.' : 'No payment records yet.'}</p></div>
      </div>

      <div className="mt-12 flex items-end justify-between"><div><SectionLabel>Your toolkit</SectionLabel><h2 className="mt-2 font-display text-2xl tracking-[-.03em]">Built for the work between the big decisions.</h2></div><span className="hidden font-mono-ui text-[10px] text-[hsl(var(--muted-foreground))] sm:block">{filteredTools.length} / 5 tools</span></div>
       {filteredTools.length ? <div className="mt-5 grid gap-4 md:grid-cols-2 xl:grid-cols-6">{filteredTools.map((tool, index) => <ToolCard key={tool.id} tool={tool} index={index} onPay={onPay} unlocked={unlocked.has(tool.id)} />)}</div> : <EmptySearch onClear={() => setSearch('')} />}

      <div className="mt-12 grid gap-4 lg:grid-cols-[1.1fr_.9fr]">
        <div className="rounded-2xl border border-[hsl(var(--card-border))] bg-[hsl(var(--card))] p-6 sm:p-7"><div className="flex items-center justify-between"><div><SectionLabel>Latest movement</SectionLabel><h2 className="mt-2 font-display text-2xl tracking-[-.03em]">Nothing to chase yet.</h2></div><span className="grid size-9 place-items-center rounded-xl bg-[hsl(var(--muted))] text-[hsl(var(--muted-foreground))]"><Clock3 size={16} /></span></div><div className="mt-7 rounded-xl border border-dashed border-[hsl(var(--border))] bg-[hsl(var(--background)/.6)] px-5 py-8 text-center"><p className="text-[13px] font-bold">Your desk is clear.</p><p className="mx-auto mt-1 max-w-xs text-[11px] leading-relaxed text-[hsl(var(--muted-foreground))]">As you add subscriptions, jobs, invoices, or claims, the useful next step will show up here.</p></div></div>
        <div className="rounded-2xl bg-[hsl(var(--accent))] p-6 text-[hsl(var(--accent-foreground))] sm:p-7"><div className="flex items-center gap-2"><ShieldCheck size={17} /><SectionLabel>Payment confidence</SectionLabel></div><h2 className="mt-7 max-w-sm font-display text-3xl leading-tight tracking-[-.03em]">Receipts do not disappear into a void.</h2><p className="mt-4 max-w-sm text-[12px] leading-relaxed text-white/70">Every transfer gets a tracking code. Our team checks the receipt before access is opened.</p><div className="mt-8 grid grid-cols-3 gap-2 border-t border-white/20 pt-5 text-[10px]"><span><b className="block text-[18px] font-normal text-white">01</b>Transfer</span><span><b className="block text-[18px] font-normal text-white">02</b>Review</span><span><b className="block text-[18px] font-normal text-white">03</b>Unlock</span></div></div>
      </div>
      <button type="button" onClick={() => { setLogoClicks((count) => count + 1); if (logoClicks >= 4) window.history.pushState({}, '', '/?admin=true'); }} className="sr-only" data-testid="button-hidden-admin-trigger">Admin</button>
    </div>
  );
}

function ToolCard({ tool, index, onPay, unlocked }: { tool: Tool; index: number; onPay: (tool: Tool) => void; unlocked: boolean }) {
  const Icon = tool.icon;
  return <div className={`animate-rise group relative overflow-hidden rounded-2xl border border-[hsl(var(--card-border))] bg-[hsl(var(--card))] p-5 transition-all duration-300 hover:-translate-y-1 hover:shadow-[var(--shadow-md)] ${index === 0 ? 'md:col-span-2 xl:col-span-3' : 'md:col-span-1 xl:col-span-2'} [animation-delay:${index * 70 + 280}ms]`} style={{ borderTopColor: `${tool.accent}66` }}>
    <div className="flex items-start justify-between"><span className="grid size-10 place-items-center rounded-xl" style={{ backgroundColor: `${tool.accent}18`, color: tool.accent }}><Icon size={19} /></span><button type="button" onClick={() => onPay(tool)} className="focus-ring rounded-lg p-1.5 text-[hsl(var(--muted-foreground))] opacity-0 transition-opacity group-hover:opacity-100 hover:bg-[hsl(var(--muted))]" data-testid={`button-more-${tool.id}`}><MoreHorizontal size={17} /></button></div>
    <div className="mt-8"><p className="font-mono-ui text-[9px] uppercase tracking-[.16em]" style={{ color: tool.accent }}>{tool.eyebrow}</p><h3 className="mt-2 font-display text-2xl tracking-[-.03em]">{tool.name}</h3><p className="mt-2 max-w-[270px] text-[12px] leading-relaxed text-[hsl(var(--muted-foreground))]">{tool.description}</p></div>
     <div className="mt-7 flex items-center justify-between border-t border-[hsl(var(--border)/.7)] pt-4"><span className="font-mono-ui text-[11px] text-[hsl(var(--muted-foreground))]">{unlocked ? <span className="inline-flex items-center gap-1.5 font-bold text-[hsl(var(--accent))]"><CheckCircle2 size={12} /> UNLOCKED</span> : <span className="inline-flex items-center gap-1.5 text-[10px] font-bold text-[hsl(var(--muted-foreground))]"><LockKeyhole size={12} /> LOCKED — Subscribe to unlock</span>}</span>{unlocked ? <Link href={`/tool/${tool.id}`} className="focus-ring inline-flex items-center gap-1.5 text-[11px] font-extrabold" style={{ color: tool.accent }} data-testid={`link-open-${tool.id}`}>Open <ArrowRight size={13} /></Link> : <button type="button" onClick={() => onPay(tool)} className="focus-ring inline-flex items-center gap-1.5 rounded-lg bg-[hsl(var(--sidebar))] px-2.5 py-1.5 text-[10px] font-extrabold text-white" data-testid={`button-subscribe-${tool.id}`}><LockKeyhole size={12} /> Subscribe · {money(tool.price)}</button>}</div>
  </div>;
}

function EmptySearch({ onClear }: { onClear: () => void }) {
  return <div className="mt-5 rounded-2xl border border-dashed border-[hsl(var(--border))] bg-[hsl(var(--card)/.5)] p-10 text-center"><Search className="mx-auto text-[hsl(var(--muted-foreground))]" size={22} /><p className="mt-3 text-[13px] font-bold">No tool matches that search.</p><button type="button" onClick={onClear} className="focus-ring mt-3 text-[12px] font-bold text-[hsl(var(--accent))]" data-testid="button-clear-tool-search">Clear search</button></div>;
}

function PaymentModal({ tool, onClose, onSubmitted }: { tool: Tool; onClose: () => void; onSubmitted: (payment: Payment) => void }) {
  const [email, setEmail] = useState('');
  const [whatsapp, setWhatsapp] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [error, setError] = useState('');
  const [progress, setProgress] = useState(0);
  const [compressed, setCompressed] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [done, setDone] = useState(false);
  const [trackingCode, setTrackingCode] = useState('');
  const Icon = tool.icon;

  useEffect(() => {
    if (progress >= 45) setCompressed(true);
  }, [progress]);

  const beginUpload = async () => {
    if (!email.trim() || !email.includes('@')) {
      setError('Add the email we should send your tracking details to.');
      return;
    }
    if (!whatsapp.trim()) {
      setError('Add a WhatsApp number so we can reach you if anything needs checking.');
      return;
    }
    if (!file) {
      setError('Attach a JPG or PNG receipt to continue.');
      return;
    }
    if (!['image/jpeg', 'image/png'].includes(file.type)) {
      setError('Only JPG and PNG images are accepted.');
      return;
    }
    if (file.size > 10 * 1024 * 1024) {
      setError('Receipt images must be smaller than 10 MB.');
      return;
    }

    setError('');
    setUploading(true);
    setProgress(1);
    try {
      const result = await submitPayment(
        {
          email: email.trim(),
          whatsapp: whatsapp.trim(),
          toolId: tool.id,
          toolName: tool.name,
          amount: tool.price,
          receipt: file,
        },
        setProgress,
      );
      setTrackingCode(result.trackingCode);
      setDone(true);
      onSubmitted({
        id: result.id,
        trackingCode: result.trackingCode,
        email,
        whatsapp,
        toolId: tool.id,
        toolName: tool.name,
        amount: tool.price,
        receiptUrl: '',
        receiptPath: '',
        submittedAt: new Date().toISOString(),
        status: 'Pending',
      });
    } catch (uploadError) {
      setError(uploadError instanceof Error ? uploadError.message : 'The receipt could not be uploaded.');
      setProgress(0);
    } finally {
      setUploading(false);
    }
  };

  const copyAccount = async () => {
    await navigator.clipboard?.writeText('Kuda Bank · 2088333205 · Okechukwu Chimaobi Destiny');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-[hsl(var(--sidebar)/.56)] p-0 backdrop-blur-sm sm:items-center sm:p-5">
      <div role="dialog" aria-modal="true" className="animate-modal max-h-[94dvh] w-full max-w-[650px] overflow-y-auto rounded-t-[24px] bg-[hsl(var(--card))] shadow-2xl sm:rounded-[24px]">
        <div className="flex items-start justify-between border-b border-[hsl(var(--border))] px-6 py-5 sm:px-8">
          <div className="flex items-center gap-3">
            <span className="grid size-10 place-items-center rounded-xl" style={{ backgroundColor: `${tool.accent}18`, color: tool.accent }}><Icon size={19} /></span>
            <div><p className="font-mono-ui text-[9px] uppercase tracking-[.16em] text-[hsl(var(--muted-foreground))]">Unlocking {tool.name}</p><h2 className="mt-1 font-display text-2xl tracking-[-.03em]">Confirm your access</h2></div>
          </div>
          <button type="button" onClick={onClose} className="focus-ring rounded-xl p-2 text-[hsl(var(--muted-foreground))] hover:bg-[hsl(var(--muted))]" data-testid="button-close-payment-modal"><X size={18} /></button>
        </div>
        {done ? (
          <div className="px-6 py-10 text-center sm:px-12">
            <div className="mx-auto grid size-14 place-items-center rounded-2xl bg-[hsl(var(--accent)/.14)] text-[hsl(var(--accent))]"><CheckCircle2 size={28} /></div>
            <p className="mt-5 font-mono-ui text-[10px] uppercase tracking-[.16em] text-[hsl(var(--accent))]">Receipt Uploaded! Awaiting Admin Approval</p>
            <h3 className="mt-2 font-display text-3xl tracking-[-.04em]">Your receipt is in review.</h3>
            <p className="mx-auto mt-3 max-w-sm text-[12px] leading-relaxed text-[hsl(var(--muted-foreground))]">Keep this tracking code nearby; your access will update after an admin approves the transfer.</p>
            <div className="mx-auto mt-6 flex max-w-xs items-center justify-between rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--background))] px-4 py-3 text-left">
              <div><span className="block font-mono-ui text-[9px] uppercase tracking-[.14em] text-[hsl(var(--muted-foreground))]">Tracking code</span><strong className="mt-1 block font-mono-ui text-[15px]">{trackingCode}</strong></div>
              <button type="button" onClick={() => navigator.clipboard?.writeText(trackingCode)} className="focus-ring rounded-lg p-2 text-[hsl(var(--muted-foreground))] hover:bg-[hsl(var(--muted))]" data-testid="button-copy-tracking-code"><Copy size={15} /></button>
            </div>
            <button type="button" onClick={onClose} className="focus-ring mt-8 rounded-xl bg-[hsl(var(--sidebar))] px-5 py-3 text-[12px] font-bold text-white" data-testid="button-close-confirmation">Back to desk</button>
          </div>
        ) : (
          <div className="space-y-6 px-6 py-6 sm:px-8">
            <div className="flex items-center justify-between rounded-xl bg-[hsl(var(--secondary)/.7)] px-4 py-3"><span className="text-[12px] text-[hsl(var(--muted-foreground))]">One-time access</span><strong className="font-display text-xl">{money(tool.price)}</strong></div>
            <div>
              <div className="flex items-center justify-between"><SectionLabel>1 / Bank transfer details</SectionLabel><span className="font-mono-ui text-[10px] text-[hsl(var(--muted-foreground))]">Reference: {tool.id.toUpperCase()}</span></div>
              <div className="mt-3 grid gap-2 sm:grid-cols-3">
                <div className="rounded-xl border border-[hsl(var(--border))] p-3"><span className="block text-[10px] text-[hsl(var(--muted-foreground))]">Bank name</span><strong className="mt-1 block text-[12px]">Kuda Bank</strong></div>
                <div className="rounded-xl border border-[hsl(var(--border))] p-3"><span className="block text-[10px] text-[hsl(var(--muted-foreground))]">Account name</span><strong className="mt-1 block text-[12px]">Okechukwu Chimaobi Destiny</strong></div>
                <button type="button" onClick={copyAccount} className="focus-ring rounded-xl border border-[hsl(var(--border))] p-3 text-left hover:bg-[hsl(var(--muted)/.7)]" data-testid="button-copy-bank-details"><span className="block text-[10px] text-[hsl(var(--muted-foreground))]">Account number</span><strong className="mt-1 block text-[12px]">2088333205 <Copy size={11} className="ml-1 inline" /></strong></button>
              </div>
              <p className="mt-3 rounded-xl bg-[hsl(var(--primary)/.08)] px-3 py-2.5 text-[11px] leading-relaxed text-[hsl(var(--foreground))]">Transfer {money(tool.price)} and upload receipt. One login. Pay once, unlock instantly.</p>
            </div>
            <div><SectionLabel>2 / Your details</SectionLabel><div className="mt-3 grid gap-3 sm:grid-cols-2"><label className="text-[11px] font-bold">Email *<input value={email} onChange={(event) => setEmail(event.target.value)} type="email" placeholder="you@business.com" className="focus-ring mt-1.5 h-11 w-full rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--background))] px-3 text-[12px] font-normal outline-none" data-testid="input-payment-email" /></label><label className="text-[11px] font-bold">WhatsApp number *<input value={whatsapp} onChange={(event) => setWhatsapp(event.target.value)} type="tel" placeholder="+234 801 234 5678" className="focus-ring mt-1.5 h-11 w-full rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--background))] px-3 text-[12px] font-normal outline-none" data-testid="input-payment-whatsapp" /></label></div></div>
            <div><SectionLabel>3 / Receipt image</SectionLabel><label className="mt-3 flex cursor-pointer flex-col items-center justify-center rounded-xl border border-dashed border-[hsl(var(--border))] bg-[hsl(var(--background)/.65)] px-5 py-6 text-center transition-colors hover:border-[hsl(var(--primary))] hover:bg-[hsl(var(--primary)/.04)]"><input type="file" accept=".jpg,.jpeg,.png,image/jpeg,image/png" onChange={(event) => { const chosen = event.target.files?.[0]; if (chosen) { setFile(chosen); setError(''); } }} className="sr-only" data-testid="input-receipt-upload" />{file ? <><FileImage className="text-[hsl(var(--accent))]" size={24} /><p className="mt-2 text-[12px] font-bold">{file.name}</p><p className="mt-1 text-[10px] text-[hsl(var(--muted-foreground))]">Ready to compress before upload</p></> : <><UploadCloud className="text-[hsl(var(--muted-foreground))]" size={23} /><p className="mt-2 text-[12px] font-bold">Drop your receipt here, or browse</p><p className="mt-1 text-[10px] text-[hsl(var(--muted-foreground))]">JPG or PNG · max 10 MB</p></>}</label></div>
            {error && <div className="flex items-center gap-2 rounded-xl bg-[hsl(var(--destructive)/.08)] px-3 py-2.5 text-[11px] text-[hsl(var(--destructive))]" data-testid="text-payment-error"><CircleAlert size={14} />{error}</div>}
            {progress > 0 && <div className="rounded-xl border border-[hsl(var(--border))] p-3"><div className="flex justify-between text-[10px]"><span className="font-bold">{progress < 100 ? 'Compressing and uploading receipt…' : 'Receipt uploaded'}</span><span className="font-mono-ui text-[hsl(var(--muted-foreground))]">{progress}%</span></div><div className="mt-2 h-1.5 overflow-hidden rounded-full bg-[hsl(var(--muted))]"><div className="h-full rounded-full bg-[hsl(var(--primary))] transition-[width] duration-150" style={{ width: `${progress}%` }} /></div>{compressed && progress < 100 && <p className="mt-2 text-[10px] text-[hsl(var(--accent))]">Compressed for faster review · smaller, still clear</p>}</div>}
            <div className="flex items-center justify-between gap-4 border-t border-[hsl(var(--border))] pt-5"><div className="flex items-center gap-2 text-[10px] text-[hsl(var(--muted-foreground))]"><LockKeyhole size={13} />Secure review, no auto-approval</div><button type="button" disabled={uploading} onClick={beginUpload} className="focus-ring inline-flex items-center gap-2 rounded-xl bg-[hsl(var(--primary))] px-5 py-3 text-[12px] font-extrabold text-[hsl(var(--primary-foreground))] disabled:cursor-wait disabled:opacity-60" data-testid="button-submit-payment">{uploading ? 'Uploading…' : 'Submit receipt'} <ArrowRight size={14} /></button></div>
            {!isFirebaseConfigured && <p className="text-[10px] leading-relaxed text-[hsl(var(--muted-foreground))]">Firebase upload is not configured in this environment yet. Add the VITE_FIREBASE_* values to enable submission.</p>}
          </div>
        )}
      </div>
    </div>
  );
}

function ToolView({ onPay, unlockedTools }: { onPay: (tool: Tool) => void; unlockedTools: Set<ToolId> }) {
  const { toolId } = useParams<{ toolId: string }>();
  const tool = TOOLS.find((item) => item.id === toolId) ?? TOOLS[0];
  const unlocked = unlockedTools.has(tool.id);
  const Icon = tool.icon;
  const [showAdd, setShowAdd] = useState(false);
  const [records, setRecords] = useState<Array<Subscription | Job | Invoice | Claim | Report>>([]);
  const [form, setForm] = useState<Record<string, string>>({});
  const addRecord = () => {
    if (!Object.values(form).some(Boolean)) return;
    if (tool.id === 'reportsnap') setRecords((items) => [...items, { period: form.period ?? '', sales: Number(form.sales ?? 0), expenses: Number(form.expenses ?? 0), profit: Number(form.sales ?? 0) - Number(form.expenses ?? 0) }]);
    else if (tool.id === 'subtrack') setRecords((items) => [...items, { service: form.service ?? '', category: form.category ?? '', monthlyCost: Number(form.monthlyCost ?? 0), renewalDate: form.renewalDate ?? '' }]);
    else if (tool.id === 'jobflow') setRecords((items) => [...items, { client: form.client ?? '', service: form.service ?? '', amount: Number(form.amount ?? 0), status: form.status ?? 'In progress', notes: form.notes ?? '', updatedAt: today() }]);
    else if (tool.id === 'paychaser') setRecords((items) => [...items, { client: form.client ?? '', invoiceNumber: form.invoiceNumber ?? '', amount: Number(form.amount ?? 0), dueDate: form.dueDate ?? '', status: form.status ?? 'Awaiting payment' }]);
    else setRecords((items) => [...items, { vendor: form.vendor ?? '', category: form.category ?? '', amount: Number(form.amount ?? 0), receiptUrl: form.receiptUrl ?? '', submittedAt: today() }]);
    setForm({}); setShowAdd(false);
  };
  const field = (key: string, label: string, placeholder: string, type = 'text') => {
    if (key === 'receiptUrl') {
      return <label className="text-[11px] font-bold">{label}<input type="file" accept=".jpg,.jpeg,.png,image/jpeg,image/png" onChange={(event) => { const receipt = event.target.files?.[0]; if (receipt) setForm((current) => ({ ...current, receiptUrl: URL.createObjectURL(receipt) })); }} className="focus-ring mt-1.5 block h-10 w-full rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--background))] px-3 py-2 text-[11px] font-normal outline-none" data-testid={`input-${tool.id}-${key}`} /></label>;
    }
    if (key === 'status') {
      const options = tool.id === 'jobflow' ? ['New', 'Quoted', 'Scheduled', 'In Progress', 'Completed', 'Invoiced'] : ['Unpaid', 'Overdue', 'Paid'];
      return <label className="text-[11px] font-bold">{label}<select value={form[key] ?? options[0]} onChange={(event) => setForm((current) => ({ ...current, [key]: event.target.value }))} className="focus-ring mt-1.5 h-10 w-full rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--background))] px-3 text-[12px] font-normal outline-none" data-testid={`input-${tool.id}-${key}`}>{options.map((option) => <option key={option} value={option}>{option}</option>)}</select></label>;
    }
    return <label className="text-[11px] font-bold">{label}<input type={type} value={form[key] ?? ''} onChange={(event) => setForm((current) => ({ ...current, [key]: event.target.value }))} placeholder={placeholder} className="focus-ring mt-1.5 h-10 w-full rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--background))] px-3 text-[12px] font-normal outline-none" data-testid={`input-${tool.id}-${key}`} /></label>;
  };
  if (!unlocked) {
    return <div className="mx-auto max-w-[760px] px-5 py-8 sm:px-8 lg:py-16">
      <Link href="/" className="focus-ring inline-flex items-center gap-2 text-[11px] font-bold text-[hsl(var(--muted-foreground))] hover:text-[hsl(var(--foreground))]" data-testid="link-back-locked-tool"><ArrowLeft size={14} /> Overview</Link>
      <div className="mt-10 overflow-hidden rounded-3xl bg-[hsl(var(--sidebar))] p-7 text-white shadow-[var(--shadow-xl)] sm:p-12">
        <div className="flex size-14 items-center justify-center rounded-2xl bg-white/10" style={{ color: tool.accent }}><LockKeyhole size={26} /></div>
        <p className="mt-8 font-mono-ui text-[10px] uppercase tracking-[.18em]" style={{ color: tool.accent }}>Locked workspace</p>
        <h1 className="mt-3 font-display text-4xl tracking-[-.05em] sm:text-6xl">{tool.name}</h1>
        <p className="mt-5 max-w-lg text-[13px] leading-relaxed text-white/60">{tool.description} Subscribe once and your operational desk will open after admin approval.</p>
        <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:items-center"><button type="button" onClick={() => onPay(tool)} className="focus-ring inline-flex items-center justify-center gap-2 rounded-xl bg-[hsl(var(--primary))] px-5 py-3 text-[12px] font-extrabold text-[hsl(var(--primary-foreground))]" data-testid={`button-locked-subscribe-${tool.id}`}><CreditCard size={15} /> Subscribe for {money(tool.price)}</button><span className="text-[10px] text-white/45">LOCKED — Subscribe to unlock</span></div>
      </div>
    </div>;
  }
  return <div className="mx-auto max-w-[1220px] px-5 py-8 sm:px-8 lg:px-11 lg:py-10">
    <Link href="/" className="focus-ring inline-flex items-center gap-2 text-[11px] font-bold text-[hsl(var(--muted-foreground))] hover:text-[hsl(var(--foreground))]" data-testid="link-back-dashboard"><ArrowLeft size={14} /> Overview</Link>
    <div className="mt-8 flex flex-col justify-between gap-6 border-b border-[hsl(var(--border))] pb-8 sm:flex-row sm:items-end"><div><div className="flex items-center gap-3"><span className="grid size-11 place-items-center rounded-xl" style={{ color: tool.accent, backgroundColor: `${tool.accent}18` }}><Icon size={21} /></span><div><SectionLabel>{tool.eyebrow}</SectionLabel><h1 className="mt-1 font-display text-4xl tracking-[-.05em] sm:text-5xl">{tool.name}</h1></div></div><p className="mt-5 max-w-lg text-[13px] leading-relaxed text-[hsl(var(--muted-foreground))]">{tool.description}</p></div><button type="button" onClick={() => onPay(tool)} className="focus-ring inline-flex items-center justify-center gap-2 rounded-xl bg-[hsl(var(--primary))] px-5 py-3 text-[12px] font-extrabold text-[hsl(var(--primary-foreground))] shadow-[0_5px_16px_hsl(var(--primary)/.16)]" data-testid={`button-unlock-${tool.id}`}><CreditCard size={15} /> Unlock {money(tool.price)}</button></div>
    <div className="mt-8 grid gap-5 lg:grid-cols-[1fr_300px]"><div className="rounded-2xl border border-[hsl(var(--card-border))] bg-[hsl(var(--card))] p-5 sm:p-7"><div className="flex items-center justify-between"><div><SectionLabel>Workspace records</SectionLabel><h2 className="mt-2 font-display text-2xl tracking-[-.03em]">{records.length ? `${records.length} record${records.length === 1 ? '' : 's'} in view` : 'A clean start'}</h2></div><button type="button" onClick={() => setShowAdd((value) => !value)} className="focus-ring inline-flex items-center gap-1.5 rounded-xl border border-[hsl(var(--border))] px-3 py-2 text-[11px] font-bold hover:bg-[hsl(var(--muted))]" data-testid={`button-add-${tool.id}`}><Plus size={14} /> Add record</button></div>
      {showAdd && <div className="mt-6 rounded-xl bg-[hsl(var(--background))] p-4"><div className="grid gap-3 sm:grid-cols-2">{tool.id === 'subtrack' && <>{field('service', 'Service', 'Google Workspace')}{field('category', 'Category', 'Software')}{field('monthlyCost', 'Monthly cost', '8500', 'number')}{field('renewalDate', 'Renewal date', '', 'date')}</>}{tool.id === 'jobflow' && <>{field('client', 'Client', 'Adebayo & Sons')}{field('service', 'Service', 'Brand identity')}{field('amount', 'Job value', '120000', 'number')}{field('status', 'Status', 'In progress')}{field('notes', 'Notes', 'Next step…')}</>}{tool.id === 'paychaser' && <>{field('client', 'Client', 'Adebayo & Sons')}{field('invoiceNumber', 'Invoice number', 'INV-004')}{field('amount', 'Amount due', '85000', 'number')}{field('dueDate', 'Due date', '', 'date')}{field('status', 'Status', 'Awaiting payment')}</>}{tool.id === 'claimdesk' && <>{field('vendor', 'Vendor', 'Mainland Print Co.')}{field('category', 'Category', 'Fulfilment')}{field('amount', 'Claim amount', '18500', 'number')}{field('receiptUrl', 'Receipt note', 'Receipt filename')}</>}{tool.id === 'reportsnap' && <>{field('period', 'Period', 'June 2025')}{field('sales', 'Sales', '480000', 'number')}{field('expenses', 'Expenses', '173500', 'number')}</>}</div><div className="mt-4 flex justify-end gap-2"><button type="button" onClick={() => setShowAdd(false)} className="focus-ring rounded-xl px-3 py-2 text-[11px] font-bold text-[hsl(var(--muted-foreground))]" data-testid={`button-cancel-add-${tool.id}`}>Cancel</button><button type="button" onClick={addRecord} className="focus-ring rounded-xl bg-[hsl(var(--sidebar))] px-4 py-2 text-[11px] font-bold text-white" data-testid={`button-save-${tool.id}`}>Save record</button></div></div>}
      {!records.length && !showAdd ? <div className="mt-7 rounded-xl border border-dashed border-[hsl(var(--border))] px-5 py-14 text-center"><span className="mx-auto grid size-11 place-items-center rounded-xl bg-[hsl(var(--muted))] text-[hsl(var(--muted-foreground))]"><FileText size={19} /></span><p className="mt-4 text-[13px] font-bold">No {tool.eyebrow.toLowerCase()} records yet.</p><p className="mx-auto mt-1 max-w-sm text-[11px] leading-relaxed text-[hsl(var(--muted-foreground))]">Add your first record to turn this desk into a useful daily view.</p><button type="button" onClick={() => setShowAdd(true)} className="focus-ring mt-5 rounded-xl bg-[hsl(var(--secondary))] px-4 py-2.5 text-[11px] font-extrabold" data-testid={`button-empty-add-${tool.id}`}>Add your first record</button></div> : records.length > 0 && <RecordsList tool={tool} records={records} />}
    </div><div className="space-y-5"><div className="rounded-2xl bg-[hsl(var(--sidebar))] p-5 text-white"><div className="flex items-center gap-2 text-[hsl(var(--primary))]"><ShieldCheck size={16} /><span className="font-mono-ui text-[9px] uppercase tracking-[.16em]">Desk note</span></div><p className="mt-5 font-display text-2xl leading-tight">Small updates compound.</p><p className="mt-3 text-[11px] leading-relaxed text-white/55">A record added today is one less loose end at the end of the month.</p></div><div className="rounded-2xl border border-[hsl(var(--card-border))] bg-[hsl(var(--card))] p-5"><SectionLabel>Access status</SectionLabel><div className="mt-4 flex items-center gap-2 text-[12px] font-bold"><span className="size-2 rounded-full bg-[hsl(var(--primary))]" />Preview mode</div><p className="mt-2 text-[11px] leading-relaxed text-[hsl(var(--muted-foreground))]">Add a payment receipt to unlock the full workspace.</p></div></div></div>
  </div>;
}

function LegacyRecordsList({ tool, records }: { tool: Tool; records: Array<Subscription | Job | Invoice | Claim | Report> }) {
  return <div className="mt-6 space-y-2">{records.map((record, index) => <div key={index} className="rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--background)/.65)] p-4" data-testid={`record-${tool.id}-${index}`}>{tool.id === 'subtrack' && <div className="flex items-center justify-between"><div><p className="text-[12px] font-bold">{(record as Subscription).service}</p><p className="mt-1 text-[10px] text-[hsl(var(--muted-foreground))]">{(record as Subscription).category} · Renews {(record as Subscription).renewalDate}</p></div><strong className="font-mono-ui text-[12px]">{money((record as Subscription).monthlyCost)}<span className="font-sans text-[9px] text-[hsl(var(--muted-foreground))]"> / mo</span></strong></div>}{tool.id === 'jobflow' && <div className="flex items-center justify-between"><div><p className="text-[12px] font-bold">{(record as Job).client}</p><p className="mt-1 text-[10px] text-[hsl(var(--muted-foreground))]">{(record as Job).service} · {(record as Job).status}</p></div><strong className="font-mono-ui text-[12px]">{money((record as Job).amount)}</strong></div>}{tool.id === 'paychaser' && <div className="flex items-center justify-between"><div><p className="text-[12px] font-bold">{(record as Invoice).client}</p><p className="mt-1 text-[10px] text-[hsl(var(--muted-foreground))]">{(record as Invoice).invoiceNumber} · {(record as Invoice).status}</p></div><strong className="font-mono-ui text-[12px]">{money((record as Invoice).amount)}</strong></div>}{tool.id === 'claimdesk' && <div className="flex items-center justify-between"><div><p className="text-[12px] font-bold">{(record as Claim).vendor}</p><p className="mt-1 text-[10px] text-[hsl(var(--muted-foreground))]">{(record as Claim).category} · Submitted {(record as Claim).submittedAt}</p></div><strong className="font-mono-ui text-[12px]">{money((record as Claim).amount)}</strong></div>}{tool.id === 'reportsnap' && <div className="grid grid-cols-4 items-center gap-3"><p className="text-[12px] font-bold">{(record as Report).period}</p><span className="text-[10px] text-[hsl(var(--muted-foreground))]">Sales<br /><b className="font-mono-ui text-[11px] text-[hsl(var(--foreground))]">{money((record as Report).sales)}</b></span><span className="text-[10px] text-[hsl(var(--muted-foreground))]">Costs<br /><b className="font-mono-ui text-[11px] text-[hsl(var(--foreground))]">{money((record as Report).expenses)}</b></span><span className="text-[10px] text-[hsl(var(--muted-foreground))]">Profit<br /><b className="font-mono-ui text-[11px] text-[hsl(var(--accent))]">{money((record as Report).profit)}</b></span></div>}</div>)}</div>;
}

function RecordsList({ tool, records }: { tool: Tool; records: Array<Subscription | Job | Invoice | Claim | Report> }) {
  const subscriptionTotal = records.reduce((total, record) => total + ((record as Subscription).monthlyCost || 0), 0);
  const unpaidTotal = records.filter((record) => !['paid', 'settled'].includes((record as Invoice).status?.toLowerCase())).reduce((total, record) => total + ((record as Invoice).amount || 0), 0);
  const overdueTotal = records.filter((record) => (record as Invoice).status?.toLowerCase().includes('overdue')).reduce((total, record) => total + ((record as Invoice).amount || 0), 0);
  const reportRecords = records as Report[];
  const maxReportValue = Math.max(...reportRecords.map((report) => report.sales), 1);

  return <div className="space-y-5">
    {tool.id === 'subtrack' && <div className="flex items-end justify-between rounded-2xl bg-[hsl(var(--secondary)/.7)] p-5"><div><SectionLabel>Monthly total</SectionLabel><p className="mt-2 text-[11px] text-[hsl(var(--muted-foreground))]">Across every tracked subscription</p></div><strong className="font-display text-3xl tracking-[-.04em]">{money(subscriptionTotal)}</strong></div>}
    {tool.id === 'paychaser' && <div className="grid gap-3 sm:grid-cols-2"><div className="rounded-2xl bg-[hsl(var(--secondary)/.7)] p-5"><SectionLabel>Unpaid</SectionLabel><strong className="mt-2 block font-display text-2xl">{money(unpaidTotal)}</strong></div><div className="rounded-2xl bg-[hsl(var(--primary)/.09)] p-5"><SectionLabel>Overdue</SectionLabel><strong className="mt-2 block font-display text-2xl text-[hsl(var(--destructive))]">{money(overdueTotal)}</strong></div></div>}
    {tool.id === 'reportsnap' && reportRecords.length > 0 && <div className="rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--background)/.55)] p-5"><div className="flex items-end justify-between"><div><SectionLabel>Sales pulse</SectionLabel><p className="mt-2 text-[11px] text-[hsl(var(--muted-foreground))]">Compare sales by reporting period</p></div><BarChart3 size={18} className="text-[hsl(var(--accent))]" /></div><div className="mt-6 flex h-32 items-end gap-3">{reportRecords.map((report) => <div key={report.period} className="group flex min-w-0 flex-1 flex-col items-center gap-2" title={`${report.period}: ${money(report.sales)}`}><div className="w-full rounded-t-lg bg-[hsl(var(--accent))] transition-opacity group-hover:opacity-70" style={{ height: `${Math.max(8, (report.sales / maxReportValue) * 100)}%` }} /><span className="max-w-full truncate text-[9px] text-[hsl(var(--muted-foreground))]">{report.period}</span></div>)}</div></div>}
    {tool.id === 'claimdesk' && <div className="rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--background)/.55)] p-5"><div className="flex items-center justify-between"><div><SectionLabel>Receipt upload log</SectionLabel><p className="mt-2 text-[11px] text-[hsl(var(--muted-foreground))]">Image evidence attached to internal claims</p></div><FileCheck2 size={18} className="text-[hsl(var(--accent))]" /></div><div className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-3">{records.map((record, index) => <div key={`${(record as Claim).vendor}-${index}`} className="overflow-hidden rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--card))]">{(record as Claim).receiptUrl ? <img src={(record as Claim).receiptUrl} alt={`Receipt for ${(record as Claim).vendor}`} className="aspect-[4/3] w-full object-cover" /> : <div className="grid aspect-[4/3] place-items-center bg-[hsl(var(--muted))] text-[hsl(var(--muted-foreground))]"><FileImage size={20} /></div>}<p className="truncate px-3 py-2 text-[10px] font-bold">{(record as Claim).vendor}</p></div>)}</div></div>}
    <LegacyRecordsList tool={tool} records={records} />
  </div>;
}

function LegacyAdminView({ payments, onStatus }: { payments: Payment[]; onStatus: (id: string, status: PaymentStatus) => void }) {
  return <div className="mx-auto max-w-[1220px] px-5 py-8 sm:px-8 lg:px-11 lg:py-10"><Link href="/" className="focus-ring inline-flex items-center gap-2 text-[11px] font-bold text-[hsl(var(--muted-foreground))] hover:text-[hsl(var(--foreground))]" data-testid="link-back-admin"><ArrowLeft size={14} /> Overview</Link><div className="mt-8 flex flex-col justify-between gap-5 sm:flex-row sm:items-end"><div><SectionLabel>Internal payment desk</SectionLabel><h1 className="mt-2 font-display text-4xl tracking-[-.05em]">Receipt review.</h1><p className="mt-3 max-w-lg text-[13px] leading-relaxed text-[hsl(var(--muted-foreground))]">A quiet queue for checking transfers before access is opened. No payment records are created until a customer submits a receipt.</p></div><div className="rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] px-4 py-3"><span className="block font-mono-ui text-[9px] uppercase tracking-[.16em] text-[hsl(var(--muted-foreground))]">Queue</span><strong className="mt-1 block font-display text-2xl">{payments.length.toString().padStart(2, '0')}</strong></div></div><div className="mt-8 rounded-2xl border border-[hsl(var(--card-border))] bg-[hsl(var(--card))] p-5 sm:p-7">{!payments.length ? <div className="py-16 text-center"><div className="mx-auto grid size-14 place-items-center rounded-2xl bg-[hsl(var(--muted))] text-[hsl(var(--muted-foreground))]"><Landmark size={24} /></div><h2 className="mt-5 font-display text-2xl tracking-[-.03em]">No receipts in the queue.</h2><p className="mx-auto mt-2 max-w-sm text-[11px] leading-relaxed text-[hsl(var(--muted-foreground))]">This is intentionally empty until Firebase is connected and a real customer submits a transfer receipt.</p><div className="mx-auto mt-6 flex max-w-xs items-center justify-center gap-2 rounded-xl bg-[hsl(var(--secondary)/.6)] px-3 py-2.5 text-left text-[10px] text-[hsl(var(--muted-foreground))]"><ShieldCheck size={14} className="shrink-0 text-[hsl(var(--accent))]" />Nothing has been fabricated here.</div></div> : <div className="overflow-x-auto"><table className="w-full min-w-[760px] text-left"><thead><tr className="border-b border-[hsl(var(--border))] text-[9px] uppercase tracking-[.16em] text-[hsl(var(--muted-foreground))]"><th className="pb-3 font-mono-ui font-normal">Customer</th><th className="pb-3 font-mono-ui font-normal">Tool</th><th className="pb-3 font-mono-ui font-normal">Amount</th><th className="pb-3 font-mono-ui font-normal">Submitted</th><th className="pb-3 font-mono-ui font-normal">Status</th><th className="pb-3 font-mono-ui font-normal">Review</th></tr></thead><tbody>{payments.map((payment) => <tr key={payment.id} className="border-b border-[hsl(var(--border)/.7)] text-[12px]" data-testid={`row-payment-${payment.id}`}><td className="py-4"><strong className="block">{payment.email}</strong><span className="mt-1 block text-[10px] text-[hsl(var(--muted-foreground))]">{payment.whatsapp} · {payment.trackingCode}</span></td><td className="py-4">{payment.toolName}</td><td className="py-4 font-mono-ui">{money(payment.amount)}</td><td className="py-4 text-[hsl(var(--muted-foreground))]">{new Date(payment.submittedAt).toLocaleDateString('en-NG')}</td><td className="py-4"><span className={`rounded-full px-2 py-1 text-[10px] font-bold ${payment.status === 'Approved' ? 'bg-[hsl(var(--accent)/.12)] text-[hsl(var(--accent))]' : payment.status === 'Rejected' ? 'bg-[hsl(var(--destructive)/.1)] text-[hsl(var(--destructive))]' : 'bg-[hsl(var(--primary)/.15)] text-[hsl(var(--foreground))]'}`}>{payment.status}</span></td><td className="py-4"><div className="flex gap-1"><button type="button" onClick={() => onStatus(payment.id, 'Approved')} className="focus-ring rounded-lg p-2 text-[hsl(var(--accent))] hover:bg-[hsl(var(--accent)/.1)]" title="Approve receipt" data-testid={`button-approve-${payment.id}`}><Check size={15} /></button><button type="button" onClick={() => onStatus(payment.id, 'Rejected')} className="focus-ring rounded-lg p-2 text-[hsl(var(--destructive))] hover:bg-[hsl(var(--destructive)/.1)]" title="Reject receipt" data-testid={`button-reject-${payment.id}`}><X size={15} /></button></div></td></tr>)}</tbody></table></div>}</div></div>;
}

function AdminView({ payments, onStatus }: { payments: Payment[]; onStatus: (id: string, status: PaymentStatus) => void }) {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'All' | PaymentStatus>('All');
  const [toolFilter, setToolFilter] = useState<'All' | ToolId>('All');
  const [receipt, setReceipt] = useState<string | null>(null);

  const counts = {
    all: payments.length,
    pending: payments.filter((payment) => payment.status === 'Pending').length,
    approved: payments.filter((payment) => payment.status === 'Approved').length,
    rejected: payments.filter((payment) => payment.status === 'Rejected').length,
  };
  const filteredPayments = useMemo(() => payments.filter((payment) => {
    const haystack = `${payment.trackingCode} ${payment.email} ${payment.toolName}`.toLowerCase();
    const matchesSearch = haystack.includes(search.toLowerCase());
    const matchesStatus = statusFilter === 'All' || payment.status === statusFilter;
    const matchesTool = toolFilter === 'All' || payment.toolId === toolFilter;
    return matchesSearch && matchesStatus && matchesTool;
  }), [payments, search, statusFilter, toolFilter]);

  const statusClass = (status: PaymentStatus) =>
    status === 'Approved'
      ? 'bg-[hsl(var(--accent)/.14)] text-[hsl(var(--accent))]'
      : status === 'Rejected'
        ? 'bg-[hsl(var(--destructive)/.1)] text-[hsl(var(--destructive))]'
        : 'bg-[hsl(var(--primary)/.15)] text-[hsl(var(--foreground))]';

  return <div className="mx-auto max-w-[1280px] px-5 py-8 sm:px-8 lg:px-11 lg:py-10">
    <Link href="/" className="focus-ring inline-flex items-center gap-2 text-[11px] font-bold text-[hsl(var(--muted-foreground))] hover:text-[hsl(var(--foreground))]" data-testid="link-back-admin"><ArrowLeft size={14} /> Overview</Link>
    <div className="mt-8 flex flex-col justify-between gap-5 lg:flex-row lg:items-end">
      <div><SectionLabel>Internal payment desk</SectionLabel><h1 className="mt-2 font-display text-4xl tracking-[-.05em] sm:text-5xl">Receipt review.</h1><p className="mt-3 max-w-lg text-[13px] leading-relaxed text-[hsl(var(--muted-foreground))]">Approve real transfer receipts to unlock the matching tool in the customer dashboard.</p></div>
      <div className="rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] px-4 py-3"><span className="block font-mono-ui text-[9px] uppercase tracking-[.16em] text-[hsl(var(--muted-foreground))]">Firebase live data</span><strong className="mt-1 block text-[11px] text-[hsl(var(--accent))]">{isFirebaseConfigured ? 'CONNECTED' : 'NOT CONFIGURED'}</strong></div>
    </div>
    <div className="mt-8 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
      {[['Total uploads', counts.all, 'all'], ['Pending', counts.pending, 'Pending'], ['Approved', counts.approved, 'Approved'], ['Rejected', counts.rejected, 'Rejected']].map(([label, count, value]) => <button type="button" key={String(label)} onClick={() => setStatusFilter(value === 'all' ? 'All' : value as PaymentStatus)} className={`rounded-2xl border p-5 text-left transition-colors ${statusFilter === (value === 'all' ? 'All' : value) ? 'border-[hsl(var(--primary)/.6)] bg-[hsl(var(--primary)/.06)]' : 'border-[hsl(var(--card-border))] bg-[hsl(var(--card))] hover:bg-[hsl(var(--muted)/.45)]'}`}><span className="font-mono-ui text-[9px] uppercase tracking-[.16em] text-[hsl(var(--muted-foreground))]">{label}</span><strong className="mt-3 block font-display text-3xl tracking-[-.04em]">{count}</strong></button>)}
    </div>
    <div className="mt-8 flex flex-col gap-3 lg:flex-row">
      <label className="relative flex-1"><Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-[hsl(var(--muted-foreground))]" /><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search tracking code, email, or tool" className="focus-ring h-11 w-full rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] pl-9 pr-3 text-[12px] outline-none placeholder:text-[hsl(var(--muted-foreground))]" data-testid="input-admin-search" /></label>
      <select value={toolFilter} onChange={(event) => setToolFilter(event.target.value as 'All' | ToolId)} className="focus-ring h-11 rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] px-3 text-[12px] outline-none lg:w-52" data-testid="select-admin-tool"><option value="All">All tools</option>{TOOLS.map((tool) => <option key={tool.id} value={tool.id}>{tool.name}</option>)}</select>
    </div>
    <div className="mt-4 flex flex-wrap gap-2">
      {(['All', 'Pending', 'Approved', 'Rejected'] as const).map((status) => <button type="button" key={status} onClick={() => setStatusFilter(status)} className={`focus-ring rounded-full px-3 py-1.5 text-[10px] font-bold ${statusFilter === status ? 'bg-[hsl(var(--sidebar))] text-white' : 'bg-[hsl(var(--muted))] text-[hsl(var(--muted-foreground))]'}`} data-testid={`button-admin-filter-${status.toLowerCase()}`}>{status}</button>)}
    </div>
    <div className="mt-6 rounded-2xl border border-[hsl(var(--card-border))] bg-[hsl(var(--card))] p-5 sm:p-7">
      {!filteredPayments.length ? <div className="py-16 text-center"><div className="mx-auto grid size-14 place-items-center rounded-2xl bg-[hsl(var(--muted))] text-[hsl(var(--muted-foreground))]"><Landmark size={24} /></div><h2 className="mt-5 font-display text-2xl tracking-[-.03em]">{payments.length ? 'No submissions match these filters.' : 'No receipts in the queue.'}</h2><p className="mx-auto mt-2 max-w-sm text-[11px] leading-relaxed text-[hsl(var(--muted-foreground))]">{payments.length ? 'Try clearing the search or selecting another status.' : 'This is intentionally empty until a real customer submits a transfer receipt through Firebase.'}</p>{!payments.length && <div className="mx-auto mt-6 flex max-w-xs items-center justify-center gap-2 rounded-xl bg-[hsl(var(--secondary)/.6)] px-3 py-2.5 text-left text-[10px] text-[hsl(var(--muted-foreground))]"><ShieldCheck size={14} className="shrink-0 text-[hsl(var(--accent))]" />Nothing has been fabricated here.</div>}</div> : <div className="space-y-3">{filteredPayments.map((payment) => <div key={payment.id} className="grid gap-4 rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--background)/.55)] p-4 lg:grid-cols-[84px_1fr_auto] lg:items-center" data-testid={`card-payment-${payment.id}`}>
        <button type="button" onClick={() => payment.receiptUrl && setReceipt(payment.receiptUrl)} disabled={!payment.receiptUrl} className="group relative grid size-[84px] place-items-center overflow-hidden rounded-xl bg-[hsl(var(--muted))] text-[hsl(var(--muted-foreground))] disabled:cursor-not-allowed" title={payment.receiptUrl ? 'View receipt' : 'Receipt preview unavailable'} data-testid={`button-view-receipt-${payment.id}`}>{payment.receiptUrl ? <img src={payment.receiptUrl} alt={`Receipt for ${payment.trackingCode}`} className="size-full object-cover transition-transform group-hover:scale-105" /> : <FileImage size={22} />}</button>
        <div className="min-w-0"><div className="flex flex-wrap items-center gap-2"><span className={`rounded-full px-2 py-1 text-[10px] font-bold ${statusClass(payment.status)}`}>{payment.status}</span><span className="font-mono-ui text-[10px] text-[hsl(var(--muted-foreground))]">{payment.trackingCode}</span></div><p className="mt-2 truncate text-[13px] font-bold">{payment.email}</p><p className="mt-1 text-[11px] text-[hsl(var(--muted-foreground))]">{payment.whatsapp} · {payment.toolName} · {money(payment.amount)}</p><p className="mt-1 text-[10px] text-[hsl(var(--muted-foreground))]">Submitted {new Date(payment.submittedAt).toLocaleString('en-NG')}</p></div>
        <div className="flex flex-wrap items-center gap-2 lg:justify-end">{payment.receiptUrl && <button type="button" onClick={() => setReceipt(payment.receiptUrl)} className="focus-ring rounded-lg border border-[hsl(var(--border))] px-3 py-2 text-[10px] font-bold hover:bg-[hsl(var(--muted))]" data-testid={`button-open-receipt-${payment.id}`}>View receipt</button>}{payment.status !== 'Approved' && <button type="button" onClick={() => onStatus(payment.id, 'Approved')} className="focus-ring rounded-lg bg-[hsl(var(--accent))] px-3 py-2 text-[10px] font-bold text-[hsl(var(--accent-foreground))]" data-testid={`button-approve-${payment.id}`}>Approve</button>}{payment.status !== 'Rejected' && <button type="button" onClick={() => onStatus(payment.id, 'Rejected')} className="focus-ring rounded-lg bg-[hsl(var(--destructive)/.1)] px-3 py-2 text-[10px] font-bold text-[hsl(var(--destructive))]" data-testid={`button-reject-${payment.id}`}>Reject</button>}</div>
      </div>)}</div>}
    </div>
    {receipt && <div className="fixed inset-0 z-[60] flex items-center justify-center bg-[hsl(var(--sidebar)/.8)] p-5 backdrop-blur-sm" onClick={() => setReceipt(null)}><button type="button" aria-label="Close receipt preview" onClick={() => setReceipt(null)} className="absolute right-5 top-5 rounded-xl bg-white/10 p-2 text-white"><X size={20} /></button><img src={receipt} alt="Full-size uploaded receipt" className="max-h-[88dvh] max-w-full rounded-2xl object-contain shadow-2xl" onClick={(event) => event.stopPropagation()} /></div>}
  </div>;
}

function Home({ payments, onPay, onStatus, unlocked }: { payments: Payment[]; onPay: (tool: Tool) => void; onStatus: (id: string, status: PaymentStatus) => void; unlocked: Set<ToolId> }) {
  const isAdmin = new URLSearchParams(window.location.search).get('admin') === 'true';
  return isAdmin ? <AdminView payments={payments} onStatus={onStatus} /> : <Dashboard onPay={onPay} payments={payments} unlocked={unlocked} />;
}

function RoutedErrorBoundary({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function AppContent() {
  const [location, setLocation] = useLocation();
  const [payments, setPayments] = useState<Payment[]>([]);
  const [paymentTool, setPaymentTool] = useState<Tool | null>(null);
  const adminMode = location.startsWith('/admin') || new URLSearchParams(window.location.search).get('admin') === 'true';
  useEffect(() => {
    return subscribeToPayments(
      (nextPayments) => setPayments(nextPayments.map((payment) => ({ ...payment, submittedAt: payment.submittedAt.toISOString() }))),
      () => setPayments([]),
    );
  }, []);
  const unlocked = useMemo(() => new Set(payments.filter((payment) => payment.status === 'Approved').map((payment) => payment.toolId)), [payments]);
  const addPayment = (payment: Payment) => setPayments((current) => [...current, payment]);
  const updatePayment = async (id: string, status: PaymentStatus) => {
    setPayments((current) => current.map((payment) => payment.id === id ? { ...payment, status } : payment));
    try {
      await updatePaymentStatus(id, status);
    } catch {
      setPayments((current) => current.map((payment) => payment.id === id ? { ...payment, status: 'Pending' } : payment));
    }
  };
  const openAdmin = () => setLocation('/?admin=true');
  return <Shell isAdmin={adminMode} onAdminTrigger={openAdmin}><RoutedErrorBoundary><Switch><Route path="/"><Home payments={payments} onPay={setPaymentTool} onStatus={updatePayment} unlocked={unlocked} /></Route><Route path="/admin"><AdminView payments={payments} onStatus={updatePayment} /></Route><Route path="/tool/:toolId"><ToolView onPay={setPaymentTool} unlockedTools={unlocked} /></Route><Route component={NotFound} /></Switch></RoutedErrorBoundary>{paymentTool && <PaymentModal tool={paymentTool} onClose={() => setPaymentTool(null)} onSubmitted={addPayment} />}</Shell>;
}

function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><AppContent /></WouterRouter><Toaster /></TooltipProvider></QueryClientProvider>;
}

export default App;